import { useTheme } from '@/contexts/ThemeContext';
import { Moon, Sun } from 'lucide-react';
import Clock from '@/components/Clock';
import WeatherCard from '@/components/WeatherCard';
import TodoList from '@/components/TodoList';
import ExpenseSummary from '@/components/ExpenseSummary';

/**
 * Home Page - Main Dashboard
 * Features all dashboard components with responsive grid layout
 * Includes dark/light mode toggle and glassmorphic design
 */
export default function Home() {
  const { theme, toggleTheme } = useTheme();

  return (
    <div className="min-h-screen bg-background transition-colors duration-300">
      {/* Header */}
      <header className="sticky top-0 z-50 backdrop-blur-md bg-background/80 border-b border-border/40">
        <div className="container py-4 flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-display font-bold text-foreground">
              My Smart Dashboard
            </h1>
            <p className="text-sm text-muted-foreground mt-1">
              Track your day, simplify your life
            </p>
          </div>

          {/* Theme Toggle */}
          <button
            onClick={toggleTheme}
            className="p-2 rounded-lg bg-accent/10 hover:bg-accent/20 text-accent transition-all duration-300 hover:scale-110 active:scale-95"
            aria-label="Toggle theme"
          >
            {theme === 'dark' ? (
              <Sun className="w-6 h-6" />
            ) : (
              <Moon className="w-6 h-6" />
            )}
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-8 pb-16">
        {/* Hero Section */}
        <div className="mb-12 text-center">
          <h2 className="text-2xl font-display font-semibold text-foreground mb-2">
            Welcome back!
          </h2>
          <p className="text-muted-foreground">
            Everything you need to manage your day in one place
          </p>
        </div>

        {/* Dashboard Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 auto-rows-max">
          {/* Clock - Full width on mobile, 2 cols on tablet, 2 cols on desktop */}
          <div className="md:col-span-2 lg:col-span-2 animate-in fade-in slide-in-from-top-4" style={{ animationDelay: '0ms' }}>
            <Clock />
          </div>

          {/* Weather - Full width on mobile, 2 cols on tablet, 2 cols on desktop */}
          <div className="md:col-span-2 lg:col-span-2 animate-in fade-in slide-in-from-top-4" style={{ animationDelay: '100ms' }}>
            <WeatherCard />
          </div>

          {/* Todo List - Full width on mobile, 1 col on tablet, 2 cols on desktop */}
          <div className="md:col-span-1 lg:col-span-2 animate-in fade-in slide-in-from-top-4" style={{ animationDelay: '200ms' }}>
            <TodoList />
          </div>

          {/* Expense Summary - Full width on mobile, 1 col on tablet, 2 cols on desktop */}
          <div className="md:col-span-1 lg:col-span-2 animate-in fade-in slide-in-from-top-4" style={{ animationDelay: '300ms' }}>
            <ExpenseSummary />
          </div>
        </div>

        {/* Footer */}
        <footer className="mt-16 pt-8 border-t border-border/40 text-center">
          <p className="text-sm text-muted-foreground">
            Built with React, Vite, and TypeScript • Glassmorphic Design
          </p>
          <p className="text-xs text-muted-foreground/60 mt-2">
            © 2024 Smart Dashboard. All rights reserved.
          </p>
        </footer>
      </main>
    </div>
  );
}
