import { useEffect, useState } from 'react';
import { Plus, Trash2, DollarSign, TrendingDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

interface Expense {
  id: string;
  name: string;
  amount: number;
  date: string;
}

/**
 * Expense Summary Component
 * Add expenses with name and amount, display total
 * Save data in localStorage with smooth animations
 */
export default function ExpenseSummary() {
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [expenseName, setExpenseName] = useState<string>('');
  const [expenseAmount, setExpenseAmount] = useState<string>('');
  const [mounted, setMounted] = useState<boolean>(false);

  // Load expenses from localStorage on mount
  useEffect(() => {
    const savedExpenses = localStorage.getItem('expenses');
    if (savedExpenses) {
      setExpenses(JSON.parse(savedExpenses));
    }
    setMounted(true);
  }, []);

  // Save expenses to localStorage whenever they change
  useEffect(() => {
    if (mounted) {
      localStorage.setItem('expenses', JSON.stringify(expenses));
    }
  }, [expenses, mounted]);

  const addExpense = (e: React.FormEvent) => {
    e.preventDefault();
    if (!expenseName.trim() || !expenseAmount.trim()) return;

    const amount = parseFloat(expenseAmount);
    if (isNaN(amount) || amount <= 0) return;

    const newExpense: Expense = {
      id: Date.now().toString(),
      name: expenseName,
      amount,
      date: new Date().toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
      }),
    };

    setExpenses([newExpense, ...expenses]);
    setExpenseName('');
    setExpenseAmount('');
  };

  const deleteExpense = (id: string) => {
    setExpenses(expenses.filter((expense) => expense.id !== id));
  };

  const totalExpenses = expenses.reduce((sum, expense) => sum + expense.amount, 0);
  const averageExpense = expenses.length > 0 ? totalExpenses / expenses.length : 0;

  return (
    <div className="backdrop-blur-md bg-card border border-border/40 rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 group h-full flex flex-col">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2 bg-accent/10 rounded-lg group-hover:bg-accent/20 transition-colors duration-300">
          <DollarSign className="w-6 h-6 text-accent" />
        </div>
        <h2 className="text-xl font-display font-semibold text-foreground">Expenses</h2>
      </div>

      {/* Total Expenses Display */}
      <div className="mb-6 p-4 bg-gradient-to-br from-accent/10 to-secondary/10 rounded-lg border border-accent/20">
        <p className="text-xs text-muted-foreground mb-1">Total Expenses</p>
        <p className="text-3xl font-display font-bold text-accent">
          ${totalExpenses.toFixed(2)}
        </p>
        {expenses.length > 0 && (
          <p className="text-xs text-muted-foreground mt-2">
            Average: ${averageExpense.toFixed(2)}
          </p>
        )}
      </div>

      {/* Add Expense Form */}
      <form onSubmit={addExpense} className="mb-6 space-y-3">
        <Input
          type="text"
          placeholder="Expense name..."
          value={expenseName}
          onChange={(e) => setExpenseName(e.target.value)}
          className="bg-input/50 border-border/40 rounded-lg focus:ring-2 focus:ring-accent/50"
        />
        <div className="flex gap-2">
          <Input
            type="number"
            placeholder="Amount..."
            value={expenseAmount}
            onChange={(e) => setExpenseAmount(e.target.value)}
            step="0.01"
            min="0"
            className="flex-1 bg-input/50 border-border/40 rounded-lg focus:ring-2 focus:ring-accent/50"
          />
          <Button
            type="submit"
            className="bg-accent hover:bg-accent/90 text-accent-foreground rounded-lg px-4"
          >
            <Plus className="w-4 h-4" />
          </Button>
        </div>
      </form>

      {/* Expenses List */}
      <div className="flex-1 overflow-y-auto space-y-2">
        {expenses.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-8 text-center">
            <TrendingDown className="w-10 h-10 text-muted-foreground/30 mb-2" />
            <p className="text-sm text-muted-foreground">No expenses yet. Start tracking!</p>
          </div>
        ) : (
          expenses.map((expense, index) => (
            <div
              key={expense.id}
              className="group/item flex items-center justify-between p-3 bg-background/50 backdrop-blur-sm rounded-lg border border-border/30 hover:border-accent/50 hover:bg-background/80 transition-all duration-200 animate-in fade-in slide-in-from-top-2"
              style={{
                animationDelay: `${index * 50}ms`,
              }}
            >
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-foreground truncate">{expense.name}</p>
                <p className="text-xs text-muted-foreground">{expense.date}</p>
              </div>

              <div className="flex items-center gap-3 ml-3 flex-shrink-0">
                <span className="text-sm font-display font-semibold text-accent">
                  ${expense.amount.toFixed(2)}
                </span>
                <button
                  onClick={() => deleteExpense(expense.id)}
                  className="text-muted-foreground hover:text-destructive opacity-0 group-hover/item:opacity-100 transition-all duration-200"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Category Breakdown (if multiple expenses) */}
      {expenses.length > 0 && (
        <div className="mt-6 pt-6 border-t border-border/30">
          <p className="text-xs font-medium text-muted-foreground mb-3">Recent Activity</p>
          <div className="space-y-2">
            {expenses.slice(0, 3).map((expense) => (
              <div key={expense.id} className="flex justify-between items-center text-xs">
                <span className="text-muted-foreground truncate">{expense.name}</span>
                <span className="text-foreground font-medium">${expense.amount.toFixed(2)}</span>
              </div>
            ))}
            {expenses.length > 3 && (
              <p className="text-xs text-muted-foreground text-center pt-2">
                +{expenses.length - 3} more
              </p>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
