import { useEffect, useState } from 'react';
import { Plus, Trash2, CheckCircle2, Circle, ListTodo } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

interface Todo {
  id: string;
  text: string;
  completed: boolean;
}

/**
 * Todo List Component
 * Add and delete tasks with localStorage persistence
 * Features smooth animations and glassmorphic design
 */
export default function TodoList() {
  const [todos, setTodos] = useState<Todo[]>([]);
  const [inputValue, setInputValue] = useState<string>('');
  const [mounted, setMounted] = useState<boolean>(false);

  // Load todos from localStorage on mount
  useEffect(() => {
    const savedTodos = localStorage.getItem('todos');
    if (savedTodos) {
      setTodos(JSON.parse(savedTodos));
    }
    setMounted(true);
  }, []);

  // Save todos to localStorage whenever they change
  useEffect(() => {
    if (mounted) {
      localStorage.setItem('todos', JSON.stringify(todos));
    }
  }, [todos, mounted]);

  const addTodo = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim()) return;

    const newTodo: Todo = {
      id: Date.now().toString(),
      text: inputValue,
      completed: false,
    };

    setTodos([newTodo, ...todos]);
    setInputValue('');
  };

  const toggleTodo = (id: string) => {
    setTodos(todos.map((todo) => (todo.id === id ? { ...todo, completed: !todo.completed } : todo)));
  };

  const deleteTodo = (id: string) => {
    setTodos(todos.filter((todo) => todo.id !== id));
  };

  const completedCount = todos.filter((todo) => todo.completed).length;

  return (
    <div className="backdrop-blur-md bg-card border border-border/40 rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 group h-full flex flex-col">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2 bg-accent/10 rounded-lg group-hover:bg-accent/20 transition-colors duration-300">
          <ListTodo className="w-6 h-6 text-accent" />
        </div>
        <div>
          <h2 className="text-xl font-display font-semibold text-foreground">Tasks</h2>
          <p className="text-xs text-muted-foreground">
            {completedCount} of {todos.length} completed
          </p>
        </div>
      </div>

      {/* Add Todo Form */}
      <form onSubmit={addTodo} className="mb-6">
        <div className="flex gap-2">
          <Input
            type="text"
            placeholder="Add a new task..."
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            className="flex-1 bg-input/50 border-border/40 rounded-lg focus:ring-2 focus:ring-accent/50"
          />
          <Button
            type="submit"
            className="bg-accent hover:bg-accent/90 text-accent-foreground rounded-lg px-4"
          >
            <Plus className="w-4 h-4" />
          </Button>
        </div>
      </form>

      {/* Todo List */}
      <div className="flex-1 overflow-y-auto space-y-2">
        {todos.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-8 text-center">
            <ListTodo className="w-10 h-10 text-muted-foreground/30 mb-2" />
            <p className="text-sm text-muted-foreground">No tasks yet. Add one to get started!</p>
          </div>
        ) : (
          todos.map((todo, index) => (
            <div
              key={todo.id}
              className="group/item flex items-center gap-3 p-3 bg-background/50 backdrop-blur-sm rounded-lg border border-border/30 hover:border-accent/50 hover:bg-background/80 transition-all duration-200 animate-in fade-in slide-in-from-top-2"
              style={{
                animationDelay: `${index * 50}ms`,
              }}
            >
              <button
                onClick={() => toggleTodo(todo.id)}
                className="flex-shrink-0 text-muted-foreground hover:text-accent transition-colors duration-200"
              >
                {todo.completed ? (
                  <CheckCircle2 className="w-5 h-5 text-accent" />
                ) : (
                  <Circle className="w-5 h-5" />
                )}
              </button>

              <span
                className={`flex-1 text-sm transition-all duration-200 ${
                  todo.completed
                    ? 'line-through text-muted-foreground'
                    : 'text-foreground font-medium'
                }`}
              >
                {todo.text}
              </span>

              <button
                onClick={() => deleteTodo(todo.id)}
                className="flex-shrink-0 text-muted-foreground hover:text-destructive opacity-0 group-hover/item:opacity-100 transition-all duration-200"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          ))
        )}
      </div>

      {/* Progress Bar */}
      {todos.length > 0 && (
        <div className="mt-6 pt-6 border-t border-border/30">
          <div className="w-full h-2 bg-background/50 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-accent to-secondary rounded-full transition-all duration-500"
              style={{
                width: `${(completedCount / todos.length) * 100}%`,
              }}
            />
          </div>
          <p className="text-xs text-muted-foreground mt-2 text-center">
            {Math.round((completedCount / todos.length) * 100)}% Complete
          </p>
        </div>
      )}
    </div>
  );
}
