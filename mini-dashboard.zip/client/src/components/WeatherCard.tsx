import { useEffect, useState } from 'react';
import { Cloud, CloudRain, Sun, Wind, Droplets, Search, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

interface WeatherData {
  temperature: number;
  condition: string;
  humidity: number;
  windSpeed: number;
  city: string;
}

/**
 * Weather Card Component
 * Fetches weather data from Open-Meteo API (no API key needed)
 * Displays temperature, condition, humidity, and wind speed
 * Features loading states and error handling
 */
export default function WeatherCard() {
  const [city, setCity] = useState<string>('New York');
  const [inputValue, setInputValue] = useState<string>('');
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string>('');

  const fetchWeather = async (cityName: string) => {
    if (!cityName.trim()) {
      setError('Please enter a city name');
      return;
    }

    setLoading(true);
    setError('');

    try {
      // First, geocode the city name to get coordinates
      const geoResponse = await fetch(
        `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(
          cityName
        )}&count=1&language=en&format=json`
      );
      const geoData = await geoResponse.json();

      if (!geoData.results || geoData.results.length === 0) {
        setError('City not found. Please try another name.');
        setLoading(false);
        return;
      }

      const { latitude, longitude, name, country } = geoData.results[0];

      // Fetch weather data using coordinates
      const weatherResponse = await fetch(
        `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m&timezone=auto`
      );
      const weatherData = await weatherResponse.json();
      const current = weatherData.current;

      // Map weather codes to conditions
      const weatherConditions: Record<number, string> = {
        0: 'Clear Sky',
        1: 'Mainly Clear',
        2: 'Partly Cloudy',
        3: 'Overcast',
        45: 'Foggy',
        48: 'Foggy',
        51: 'Light Drizzle',
        53: 'Moderate Drizzle',
        55: 'Dense Drizzle',
        61: 'Slight Rain',
        63: 'Moderate Rain',
        65: 'Heavy Rain',
        71: 'Slight Snow',
        73: 'Moderate Snow',
        75: 'Heavy Snow',
        80: 'Slight Rain Showers',
        81: 'Moderate Rain Showers',
        82: 'Violent Rain Showers',
        85: 'Slight Snow Showers',
        86: 'Heavy Snow Showers',
        95: 'Thunderstorm',
        96: 'Thunderstorm with Hail',
        99: 'Thunderstorm with Hail',
      };

      setWeather({
        temperature: Math.round(current.temperature_2m),
        condition: weatherConditions[current.weather_code] || 'Unknown',
        humidity: current.relative_humidity_2m,
        windSpeed: Math.round(current.wind_speed_10m),
        city: `${name}, ${country}`,
      });
      setCity(cityName);
      setInputValue('');
    } catch (err) {
      setError('Failed to fetch weather data. Please try again.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchWeather('New York');
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    fetchWeather(inputValue || city);
  };

  const getWeatherIcon = () => {
    if (!weather) return null;
    const condition = weather.condition.toLowerCase();
    if (condition.includes('rain') || condition.includes('drizzle')) {
      return <CloudRain className="w-12 h-12 text-blue-400" />;
    }
    if (condition.includes('cloud')) {
      return <Cloud className="w-12 h-12 text-gray-400" />;
    }
    return <Sun className="w-12 h-12 text-yellow-400" />;
  };

  return (
    <div className="backdrop-blur-md bg-card border border-border/40 rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 group">
      <h2 className="text-xl font-display font-semibold text-foreground mb-6">Weather</h2>

      {/* Search Form */}
      <form onSubmit={handleSearch} className="mb-6">
        <div className="flex gap-2">
          <Input
            type="text"
            placeholder="Search city..."
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            className="flex-1 bg-input/50 border-border/40 rounded-lg focus:ring-2 focus:ring-accent/50"
          />
          <Button
            type="submit"
            disabled={loading}
            className="bg-accent hover:bg-accent/90 text-accent-foreground rounded-lg px-4"
          >
            <Search className="w-4 h-4" />
          </Button>
        </div>
      </form>

      {/* Error State */}
      {error && (
        <div className="flex items-center gap-2 p-3 bg-destructive/10 border border-destructive/30 rounded-lg mb-4">
          <AlertCircle className="w-4 h-4 text-destructive flex-shrink-0" />
          <p className="text-sm text-destructive">{error}</p>
        </div>
      )}

      {/* Loading State */}
      {loading && (
        <div className="flex items-center justify-center py-8">
          <div className="w-8 h-8 border-3 border-accent/30 border-t-accent rounded-full animate-spin" />
        </div>
      )}

      {/* Weather Display */}
      {weather && !loading && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground mb-1">{weather.city}</p>
              <div className="flex items-baseline gap-2">
                <span className="text-4xl font-display font-bold text-foreground">
                  {weather.temperature}°
                </span>
                <span className="text-lg text-muted-foreground">C</span>
              </div>
              <p className="text-sm text-muted-foreground mt-1">{weather.condition}</p>
            </div>
            <div className="flex-shrink-0">{getWeatherIcon()}</div>
          </div>

          {/* Weather Details Grid */}
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-background/50 backdrop-blur-sm rounded-lg p-4 border border-border/30">
              <div className="flex items-center gap-2 mb-2">
                <Droplets className="w-4 h-4 text-blue-400" />
                <span className="text-xs text-muted-foreground font-medium">Humidity</span>
              </div>
              <p className="text-2xl font-display font-semibold text-foreground">
                {weather.humidity}%
              </p>
            </div>

            <div className="bg-background/50 backdrop-blur-sm rounded-lg p-4 border border-border/30">
              <div className="flex items-center gap-2 mb-2">
                <Wind className="w-4 h-4 text-cyan-400" />
                <span className="text-xs text-muted-foreground font-medium">Wind Speed</span>
              </div>
              <p className="text-2xl font-display font-semibold text-foreground">
                {weather.windSpeed} km/h
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
