import { useEffect, useState } from 'react';
import { Clock as ClockIcon } from 'lucide-react';

/**
 * Clock Component
 * Displays the current time and updates every second
 * Uses glassmorphic card design with smooth animations
 */
export default function Clock() {
  const [time, setTime] = useState<string>('');
  const [date, setDate] = useState<string>('');

  useEffect(() => {
    // Set initial time
    const updateTime = () => {
      const now = new Date();
      const hours = String(now.getHours()).padStart(2, '0');
      const minutes = String(now.getMinutes()).padStart(2, '0');
      const seconds = String(now.getSeconds()).padStart(2, '0');
      setTime(`${hours}:${minutes}:${seconds}`);

      // Format date
      const options: Intl.DateTimeFormatOptions = {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
      };
      setDate(now.toLocaleDateString('en-US', options));
    };

    updateTime();
    const interval = setInterval(updateTime, 1000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="backdrop-blur-md bg-card border border-border/40 rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 group">
      <div className="flex items-center gap-3 mb-4">
        <div className="p-2 bg-accent/10 rounded-lg group-hover:bg-accent/20 transition-colors duration-300">
          <ClockIcon className="w-6 h-6 text-accent" />
        </div>
        <h2 className="text-xl font-display font-semibold text-foreground">Current Time</h2>
      </div>

      <div className="space-y-3">
        <div className="text-5xl font-display font-bold text-accent tabular-nums">
          {time || '00:00:00'}
        </div>
        <p className="text-sm text-muted-foreground font-medium">
          {date || 'Loading...'}
        </p>
      </div>

      {/* Decorative element */}
      <div className="mt-6 h-1 bg-gradient-to-r from-accent/50 via-accent to-accent/50 rounded-full opacity-60 group-hover:opacity-100 transition-opacity duration-300" />
    </div>
  );
}
